# Чекер airdrops

## Установка
`npm install` 

Заполняем файлы адресами в папке `addresses`

Для запуска `npm start`

### Чекер

* Altlayer
* Rabby points
* Zetachain
* Frame
* Anoma
* Dymension
* MEME
